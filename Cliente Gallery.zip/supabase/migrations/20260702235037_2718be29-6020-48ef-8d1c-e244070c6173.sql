
CREATE POLICY "Public can read photos" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'photos');
CREATE POLICY "Authenticated can upload photos" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'photos' AND owner = auth.uid());
CREATE POLICY "Owner can update photos" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'photos' AND owner = auth.uid());
CREATE POLICY "Owner can delete photos" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'photos' AND owner = auth.uid());
