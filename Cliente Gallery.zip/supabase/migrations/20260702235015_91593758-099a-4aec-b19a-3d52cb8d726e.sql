
CREATE TABLE public.albums (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  client_name TEXT NOT NULL,
  client_email TEXT,
  client_phone TEXT,
  event_name TEXT NOT NULL,
  event_date DATE,
  cover_url TEXT,
  password_hash TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.albums (slug);
CREATE INDEX ON public.albums (created_by);

GRANT SELECT ON public.albums TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.albums TO authenticated;
GRANT ALL ON public.albums TO service_role;
ALTER TABLE public.albums ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view albums" ON public.albums FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Owner can insert" ON public.albums FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Owner can update" ON public.albums FOR UPDATE TO authenticated USING (auth.uid() = created_by);
CREATE POLICY "Owner can delete" ON public.albums FOR DELETE TO authenticated USING (auth.uid() = created_by);

CREATE TABLE public.photos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  album_id UUID NOT NULL REFERENCES public.albums(id) ON DELETE CASCADE,
  storage_path TEXT NOT NULL,
  file_name TEXT,
  width INT,
  height INT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.photos (album_id);

GRANT SELECT ON public.photos TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.photos TO authenticated;
GRANT ALL ON public.photos TO service_role;
ALTER TABLE public.photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view photos" ON public.photos FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Owner can insert photos" ON public.photos FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.albums a WHERE a.id = album_id AND a.created_by = auth.uid()));
CREATE POLICY "Owner can update photos" ON public.photos FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.albums a WHERE a.id = album_id AND a.created_by = auth.uid()));
CREATE POLICY "Owner can delete photos" ON public.photos FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.albums a WHERE a.id = album_id AND a.created_by = auth.uid()));

CREATE TABLE public.favorites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  album_id UUID NOT NULL REFERENCES public.albums(id) ON DELETE CASCADE,
  photo_id UUID NOT NULL REFERENCES public.photos(id) ON DELETE CASCADE,
  visitor_token TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (photo_id, visitor_token)
);
CREATE INDEX ON public.favorites (album_id, visitor_token);

GRANT SELECT, INSERT, DELETE ON public.favorites TO anon, authenticated;
GRANT ALL ON public.favorites TO service_role;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view favorites" ON public.favorites FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can add favorites" ON public.favorites FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can remove favorites" ON public.favorites FOR DELETE TO anon, authenticated USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_albums_updated_at BEFORE UPDATE ON public.albums
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
