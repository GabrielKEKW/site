# By Ana Esther — Plataforma de Proofing

Plataforma minimalista e editorial para fotografia, inspirada em Pixieset / Pic-Time / ShootProof. Cada álbum tem link único (slug) — o cliente acessa sem criar conta, apenas com uma senha opcional do álbum.

## Design

- **Paleta**: Paper & Ink (off-white `#f5f3ee`, preto `#0d0d0d`) — clean, editorial, deixa as fotos brilharem.
- **Tipografia**: Cormorant (display serif elegante) + Karla (sans-serif limpa).
- **Layout do catálogo**: Gallery grid uniforme, com lightbox em tela cheia.
- **Espírito**: silencioso, luxuoso, sem distrações — só as fotos.

## Fluxos

### Área da fotógrafa (Ana) — `/admin`
- Login por e-mail/senha (só Ana).
- Dashboard com lista de álbuns criados.
- Criar álbum: nome do cliente, e-mail, telefone, nome do evento, data, senha opcional, capa.
- Upload de fotos (múltiplas, arrastar e soltar) — armazenadas em alta qualidade no storage.
- Cada álbum gera um link único: `/album/{slug}`.
- Copiar link para enviar ao cliente.

### Área do cliente — `/album/{slug}`
- Capa com nome do evento + nome do cliente + data.
- (Se protegido) tela de senha antes de entrar.
- Galeria em grid; clique abre lightbox.
- Botão **Baixar em alta qualidade** por foto e **Baixar tudo** (zip via download sequencial).
- Marcar favoritas (persistido por álbum, sem login — via localStorage + registro no banco pelo slug).

### Home `/`
- Hero editorial "By Ana Esther — Fotografia".
- Pequena vitrine.
- Link discreto "Acessar álbum" (campo pra colar slug) e "Área da fotógrafa".

## Técnico

- **Lovable Cloud** para: auth (só Ana), banco (`albums`, `photos`, `favorites`), storage (bucket público `photos` para permitir download em alta).
- **Tabelas**:
  - `albums` (id, slug único, client_name, client_email, client_phone, event_name, event_date, cover_url, password_hash nullable, created_by, created_at).
  - `photos` (id, album_id, storage_path, width, height, order, created_at).
  - `favorites` (id, album_id, photo_id, visitor_token, created_at).
- **RLS**:
  - `albums`: SELECT público por slug (colunas seguras); INSERT/UPDATE/DELETE apenas dono.
  - `photos`: SELECT público quando `album_id` existe; escrita só dono.
  - `favorites`: INSERT/SELECT/DELETE público (identificado por visitor_token).
- **Storage**: bucket `photos` público para download direto em alta qualidade.
- **Senha do álbum**: hash guardado no banco; server function valida e retorna sessão temporária (cookie httpOnly / token em memória).
- **Rotas**:
  - `/` home
  - `/auth` login da Ana
  - `/_authenticated/admin` dashboard
  - `/_authenticated/admin/albums/$id` gestão do álbum + upload
  - `/album/$slug` visão do cliente
  - `/album/$slug/password` (se protegido)

## Entrega nesta iteração

1. Ativar Lovable Cloud.
2. Design system (Paper & Ink + Cormorant/Karla).
3. Migração inicial (tabelas + RLS + bucket).
4. Home + Auth + Admin (criar álbum, upload, listar).
5. Página pública do álbum com lightbox, download por foto e favoritar.
6. Proteção por senha do álbum.

Confirma que posso seguir?
