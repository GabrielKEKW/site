import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { areas } from "@/lib/areas";
import { uploadOrcamentoPhotos } from "@/lib/orcamento-upload.functions";
import { useServerFn } from "@tanstack/react-start";

const searchSchema = z.object({
  area: z.string().optional(),
});

export const Route = createFileRoute("/orcamento")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Orçamento — By Ana Esther" },
      { name: "description", content: "Solicite um orçamento personalizado para foto, vídeo, drone, design ou edição." },
      { property: "og:title", content: "Orçamento — By Ana Esther" },
      { property: "og:description", content: "Solicite um orçamento personalizado." },
    ],
  }),
  component: OrcamentoPage,
});

function OrcamentoPage() {
  const { area: preselected } = Route.useSearch();
  const doUpload = useServerFn(uploadOrcamentoPhotos);
  const [form, setForm] = useState({
    nome: "",
    email: "",
    telefone: "",
    area: preselected ?? "",
    prazo: "",
    etapa: "",
    material: "",
    descricao: "",
  });
  const [files, setFiles] = useState<{ file: File; preview: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  async function resizeAndCompress(file: File): Promise<{ name: string; type: string; data: string }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const reader = new FileReader();
      reader.onload = (e) => {
        img.onload = () => {
          const maxWidth = 1600;
          const maxHeight = 1600;
          let { width, height } = img;
          if (width > maxWidth || height > maxHeight) {
            const ratio = Math.min(maxWidth / width, maxHeight / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
          }
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (!ctx) return reject(new Error("Canvas não suportado"));
          ctx.drawImage(img, 0, 0, width, height);
          const data = canvas.toDataURL("image/jpeg", 0.85);
          resolve({ name: file.name.replace(/\.[^.]+$/, ".jpg"), type: "image/jpeg", data });
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setUploading(true);
    setError("");
    let photoLinks: { path: string; url: string }[] = [];

    try {
      if (files.length > 0) {
        const compressed = await Promise.all(files.map((f) => resizeAndCompress(f.file)));
        photoLinks = await doUpload({ data: { files: compressed } });
      }
    } catch (err) {
      setUploading(false);
      setError("Não foi possível enviar as fotos. Tente novamente ou envie por e-mail direto.");
      return;
    }

    const areaLabel = areas.find((a) => a.key === form.area)?.label ?? "Geral";
    const etapaLabel =
      form.etapa === "ideia"
        ? "Tenho uma ideia, quero construir do zero"
        : form.etapa === "parte"
        ? "Já tenho parte do material, preciso de ajuda para fechar"
        : form.etapa === "pronto"
        ? "Já tenho quase tudo pronto, só preciso de ajuste/acabamento"
        : form.etapa === "naosei"
        ? "Ainda não sei direito, quero conversar"
        : "Não informado";
    const subject = `Orçamento · ${areaLabel} · ${form.nome}`;
    const photoSection =
      photoLinks.length > 0
        ? `\nFotos de referência/anexo:\n${photoLinks.map((p) => `- ${p.url}`).join("\n")}\n`
        : "";
    const body =
      `Nome: ${form.nome}\n` +
      `E-mail: ${form.email}\n` +
      `Telefone: ${form.telefone}\n` +
      `Área: ${areaLabel}\n` +
      `Prazo desejado: ${form.prazo}\n` +
      `Etapa do projeto: ${etapaLabel}\n` +
      (form.material ? `O que já existe: ${form.material}\n` : "") +
      `\nDescrição do projeto:\n${form.descricao}` +
      photoSection;
    window.location.href = `mailto:contato@byanaesther.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setUploading(false);
    setSent(true);
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(e.target.files || []);
    const newFiles = selected.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setFiles((prev) => [...prev, ...newFiles].slice(0, 10));
    e.target.value = "";
  }

  function removeFile(index: number) {
    setFiles((prev) => {
      const next = [...prev];
      URL.revokeObjectURL(next[index].preview);
      next.splice(index, 1);
      return next;
    });
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between px-6 md:px-12 py-5 border-b border-border">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid place-items-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-display font-black italic text-lg leading-none pb-0.5">A</span>
          <div className="text-[10px] tracking-[0.3em] uppercase leading-tight">
            By Ana Esther<br />
            <span className="text-muted-foreground">Direção Criativa</span>
          </div>
        </Link>
        <nav className="flex items-center gap-6 text-[10px] tracking-[0.25em] uppercase">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        </nav>
      </header>

      <section className="bg-primary text-primary-foreground py-20 md:py-28 px-6 md:px-12">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-[10px] tracking-[0.4em] uppercase opacity-80 mb-6">Orçamento personalizado</p>
          <h1 className="font-display font-black italic text-5xl md:text-7xl leading-[0.95]">
            Conta pra mim<br />o que você <span className="text-brand-peach">imagina</span>.
          </h1>
          <p className="mt-8 text-sm md:text-base opacity-90 max-w-xl mx-auto">
            Cada projeto é único. Me manda os detalhes e eu te respondo com um orçamento sob medida em até 3 dias úteis.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-2xl px-6 md:px-12 py-16 md:py-24">
        <form onSubmit={onSubmit} className="space-y-6">
          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Nome *</label>
            <input
              required
              value={form.nome}
              onChange={(e) => setForm({ ...form, nome: e.target.value })}
              className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">E-mail *</label>
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors"
              />
            </div>
            <div>
              <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Telefone</label>
              <input
                type="tel"
                value={form.telefone}
                onChange={(e) => setForm({ ...form, telefone: e.target.value })}
                className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Área *</label>
            <select
              required
              value={form.area}
              onChange={(e) => setForm({ ...form, area: e.target.value })}
              className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors"
            >
              <option value="">Selecione uma área</option>
              {areas.map((a) => (
                <option key={a.key} value={a.key}>{a.label}</option>
              ))}
              <option value="outro">Outro / múltiplas áreas</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Prazo desejado</label>
            <input
              placeholder="Ex: até o fim do mês, sem pressa..."
              value={form.prazo}
              onChange={(e) => setForm({ ...form, prazo: e.target.value })}
              className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors"
            />
          </div>

          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Onde você está no projeto? *</label>
            <div className="mt-3 grid gap-3">
              {[
                { value: "ideia", label: "Tenho uma ideia, quero construir do zero" },
                { value: "parte", label: "Já tenho parte do material, preciso de ajuda para fechar" },
                { value: "pronto", label: "Já tenho quase tudo pronto, só preciso de ajuste/acabamento" },
                { value: "naosei", label: "Ainda não sei direito, quero conversar" },
              ].map((opt) => (
                <label
                  key={opt.value}
                  className={`flex items-start gap-3 border rounded-2xl p-4 cursor-pointer transition-colors ${
                    form.etapa === opt.value
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <input
                    type="radio"
                    name="etapa"
                    required
                    value={opt.value}
                    checked={form.etapa === opt.value}
                    onChange={(e) => setForm({ ...form, etapa: e.target.value })}
                    className="mt-1 accent-primary"
                  />
                  <span className="text-sm leading-snug">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {(form.etapa === "parte" || form.etapa === "pronto") && (
            <div>
              <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">O que você já tem?</label>
              <textarea
                rows={3}
                placeholder="Ex: fotos brutas, logotipo pronto, vídeos captados, roteiro, referências..."
                value={form.material}
                onChange={(e) => setForm({ ...form, material: e.target.value })}
                className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors resize-none"
              />
            </div>
          )}

          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Conta sobre o projeto *</label>
            <textarea
              required
              rows={6}
              placeholder="Referências, formato, quantidade, locação, briefing..."
              value={form.descricao}
              onChange={(e) => setForm({ ...form, descricao: e.target.value })}
              className="mt-2 w-full border border-border bg-transparent px-4 py-3 text-sm rounded-lg focus:outline-none focus:border-primary transition-colors resize-none"
            />
          </div>

          <div>
            <label className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Fotos de referência ou anexo</label>
            <p className="text-xs text-muted-foreground mt-1 mb-3">
              Se quiser, anexe imagens que ajudem a entender o projeto. Máximo de 10 fotos.
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {files.map((f, i) => (
                <div key={i} className="relative aspect-square rounded-xl overflow-hidden border border-border">
                  <img src={f.preview} alt={`Anexo ${i + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removeFile(i)}
                    className="absolute top-1 right-1 h-6 w-6 rounded-full bg-brand-ink text-white text-xs grid place-items-center"
                    aria-label="Remover foto"
                  >
                    ×
                  </button>
                </div>
              ))}
              {files.length < 10 && (
                <label className="aspect-square rounded-xl border border-dashed border-border flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-primary transition-colors">
                  <span className="text-2xl leading-none">+</span>
                  <span className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground text-center">Adicionar</span>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </label>
              )}
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            Os valores são calculados a partir do escopo do projeto — cada orçamento é feito sob medida.
          </p>

          <button
            type="submit"
            disabled={uploading}
            className="w-full bg-brand-ink text-white px-8 py-4 text-xs tracking-[0.3em] uppercase rounded-full hover:bg-primary transition disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {uploading ? "Enviando fotos..." : "Enviar pedido de orçamento"}
          </button>

          {error && (
            <p className="text-center text-sm text-red-500">{error}</p>
          )}

          {sent && (
            <p className="text-center text-sm text-primary">
              Abrindo seu app de e-mail... Se nada abrir, escreva direto para contato@byanaesther.com.
            </p>
          )}
        </form>
      </section>

      <footer className="bg-brand-ink text-white/70 py-8 text-center text-[10px] tracking-[0.3em] uppercase">
        © By Ana Esther · Direção Criativa
      </footer>
    </div>
  );
}