import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/")({
  component: Index,
});

import { areas } from "@/lib/areas";

function Index() {
  const [slug, setSlug] = useState("");
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* NAV */}
      <header className="flex items-center justify-between px-6 md:px-12 py-5 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="grid place-items-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-display font-black italic text-lg leading-none pb-0.5">A</span>
          <div className="text-[10px] tracking-[0.3em] uppercase leading-tight">
            By Ana Esther<br/>
            <span className="text-muted-foreground">Direção Criativa</span>
          </div>
        </div>
        <nav className="flex items-center gap-6 text-[10px] tracking-[0.25em] uppercase">
          <a href="#areas" className="hover:text-primary transition-colors hidden sm:block">Áreas</a>
          <a href="#album" className="hover:text-primary transition-colors">Álbum</a>
          <Link to="/auth" className="text-muted-foreground hover:text-primary transition-colors">Entrar</Link>
        </nav>
      </header>

      {/* HERO — CHEGOU */}
      <section className="relative bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute top-6 left-6 md:top-10 md:left-10 font-display italic font-black text-[18vw] md:text-[10rem] leading-none opacity-20 select-none">by</div>
        <div className="absolute bottom-6 right-6 md:bottom-10 md:right-10 font-display italic font-black text-[18vw] md:text-[10rem] leading-none opacity-20 select-none">Ae</div>

        <div className="relative mx-auto max-w-5xl px-6 md:px-12 py-24 md:py-36 text-center">
          <p className="text-[10px] tracking-[0.4em] uppercase mb-8 opacity-80">Chegou · nova identidade</p>
          <h1 className="font-display font-black italic text-6xl md:text-8xl lg:text-9xl leading-[0.9]">
            by Ana<br/>Esther<span className="text-brand-peach">.</span>
          </h1>
          <p className="mt-8 text-sm md:text-base tracking-widest uppercase opacity-90">
            Direção Criativa · Foto · Vídeo · Drone
          </p>
        </div>
      </section>

      {/* MANIFESTO */}
      <section className="mx-auto max-w-3xl px-6 md:px-12 py-24 md:py-32 text-center">
        <p className="text-[10px] tracking-[0.35em] uppercase text-primary mb-6">Manifesto</p>
        <h2 className="font-display italic font-black text-4xl md:text-6xl leading-[1.05]">
          "Não para. Nunca.<br/>
          Constrói acessos.<br/>
          Constrói <span className="text-brand-orange">mundo</span>."
        </h2>
        <p className="mt-8 text-sm md:text-base text-muted-foreground max-w-xl mx-auto">
          Carrega muito mais do que parece — e sempre encontra um caminho.
          Uma direção criativa feita de coragem, cuidado e imagem.
        </p>
      </section>

      {/* ÁREAS DE TRABALHO */}
      <section id="areas" className="bg-brand-ink text-white py-24 md:py-32">
        <div className="mx-auto max-w-6xl px-6 md:px-12">
          <div className="text-center mb-16">
            <p className="text-[10px] tracking-[0.35em] uppercase text-brand-peach mb-4">Portfolio</p>
            <h2 className="font-display italic font-black text-5xl md:text-7xl leading-none">
              Áreas de<br/>
              <span className="not-italic font-black tracking-tight">TRABALHO</span>
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
            {areas.map((a, i) => (
              <Link
                key={a.key}
                to="/servicos/$area"
                params={{ area: a.key }}
                className={`${a.bg} ${a.fg} p-6 md:p-8 rounded-2xl aspect-square flex flex-col justify-between transition-transform hover:-translate-y-1 ${i === 4 ? "col-span-2 md:col-span-1" : ""}`}
              >
                <div className="flex items-start justify-between">
                  <span className="text-[10px] tracking-[0.3em] uppercase opacity-70">0{i + 1}</span>
                  <span className="h-8 w-8 rounded-full border border-current grid place-items-center text-xs">↗</span>
                </div>
                <div>
                  <div className="font-display italic font-black text-3xl md:text-4xl leading-none">{a.label}</div>
                  <p className="mt-3 text-xs md:text-sm opacity-90 leading-snug">{a.desc}</p>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              to="/orcamento"
              className="inline-block bg-brand-peach text-brand-ink px-10 py-4 text-xs tracking-[0.3em] uppercase rounded-full hover:bg-white transition"
            >
              Solicitar orçamento
            </Link>
          </div>
        </div>
      </section>


      {/* ACESSO AO ÁLBUM */}
      <section id="album" className="bg-brand-peach text-brand-ink py-24 md:py-32">
        <div className="mx-auto max-w-2xl px-6 md:px-12 text-center">
          <p className="text-[10px] tracking-[0.35em] uppercase mb-6">Área do cliente</p>
          <h2 className="font-display italic font-black text-5xl md:text-6xl leading-none">
            Acessar<br/>seu álbum.
          </h2>
          <p className="mt-6 text-sm md:text-base opacity-80 max-w-md mx-auto">
            Digite o código do seu ensaio para ver, favoritar e baixar cada foto em alta qualidade.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (slug.trim()) window.location.href = `/album/${slug.trim()}`;
            }}
            className="mt-10 flex flex-col sm:flex-row items-stretch gap-2 max-w-md mx-auto"
          >
            <input
              type="text"
              placeholder="código do álbum"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              className="flex-1 border border-brand-ink bg-transparent px-4 py-3 text-sm placeholder:text-brand-ink/50 focus:outline-none focus:bg-white/50 transition-colors rounded-full"
            />
            <button
              type="submit"
              className="bg-brand-ink text-white px-8 py-3 text-xs tracking-[0.25em] uppercase hover:bg-primary transition rounded-full"
            >
              Entrar
            </button>
          </form>
        </div>
      </section>

      {/* GROW */}
      <section className="bg-background py-24 md:py-32 text-center border-t border-border">
        <p className="text-[10px] tracking-[0.35em] uppercase text-primary mb-6">Vamos juntos?</p>
        <h2 className="font-display italic font-black text-6xl md:text-8xl leading-none">
          Let's <span className="text-brand-orange">grow!</span>
        </h2>
        <a
          href="mailto:contato@byanaesther.com"
          className="inline-block mt-10 bg-brand-ink text-white px-10 py-4 text-xs tracking-[0.3em] uppercase rounded-full hover:bg-primary transition"
        >
          Falar com a Ana
        </a>
      </section>

      <footer className="bg-brand-ink text-white/70 py-8 text-center text-[10px] tracking-[0.3em] uppercase">
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="h-2 w-2 rounded-full bg-brand-red" />
          <span className="h-2 w-2 rounded-full bg-brand-orange" />
          <span className="h-2 w-2 rounded-full bg-brand-peach" />
          <span className="h-2 w-2 rounded-full bg-brand-blush" />
          <span className="h-2 w-2 rounded-full bg-white" />
        </div>
        © By Ana Esther · Direção Criativa
      </footer>
    </div>
  );
}
