import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getVisitorToken } from "@/lib/slug";
import { verifyAlbumPassword } from "@/lib/album-password.functions";
import { useServerFn } from "@tanstack/react-start";

export const Route = createFileRoute("/album/$slug")({
  head: () => ({
    meta: [
      { title: "Álbum — By Ana Esther" },
      { name: "description", content: "Seu ensaio, guardado com cuidado." },
      { property: "og:title", content: "Álbum — By Ana Esther" },
      { property: "og:description", content: "Seu ensaio, guardado com cuidado." },
    ],
  }),
  component: AlbumView,
});

type Album = {
  id: string; slug: string; client_name: string; event_name: string;
  event_date: string | null; cover_url: string | null; password_hash: string | null;
};
type Photo = { id: string; storage_path: string; file_name: string | null };

function photoUrl(path: string) {
  const base = import.meta.env.VITE_SUPABASE_URL;
  return `${base}/storage/v1/object/public/photos/${path}`;
}

function AlbumView() {
  const { slug } = Route.useParams();
  const [album, setAlbum] = useState<Album | null | "notfound">(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [pwError, setPwError] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [showFavOnly, setShowFavOnly] = useState(false);
  const verifyPw = useServerFn(verifyAlbumPassword);

  const visitorToken = useMemo(() => getVisitorToken(), []);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("albums")
        .select("id, slug, client_name, event_name, event_date, cover_url, password_hash")
        .eq("slug", slug).maybeSingle();
      if (!data) { setAlbum("notfound"); return; }
      setAlbum(data as Album);
      const needsPassword = !!data.password_hash;
      const cached = sessionStorage.getItem(`album-unlock-${slug}`) === "1";
      if (!needsPassword || cached) {
        setUnlocked(true);
        loadPhotos(data.id);
      }
    })();
  }, [slug]);

  async function loadPhotos(albumId: string) {
    const [{ data: p }, { data: f }] = await Promise.all([
      supabase.from("photos").select("id, storage_path, file_name").eq("album_id", albumId).order("sort_order"),
      supabase.from("favorites").select("photo_id").eq("album_id", albumId).eq("visitor_token", visitorToken),
    ]);
    setPhotos((p as Photo[]) ?? []);
    setFavorites(new Set((f ?? []).map((r: any) => r.photo_id)));
  }

  async function submitPassword(e: React.FormEvent) {
    e.preventDefault();
    if (!album || album === "notfound") return;
    setPwLoading(true); setPwError(false);
    try {
      const { ok } = await verifyPw({ data: { slug, password } });
      if (ok) {
        sessionStorage.setItem(`album-unlock-${slug}`, "1");
        setUnlocked(true);
        loadPhotos(album.id);
      } else setPwError(true);
    } finally { setPwLoading(false); }
  }

  async function toggleFavorite(photoId: string) {
    if (!album || album === "notfound") return;
    const isFav = favorites.has(photoId);
    const next = new Set(favorites);
    if (isFav) {
      next.delete(photoId);
      await supabase.from("favorites").delete().eq("photo_id", photoId).eq("visitor_token", visitorToken);
    } else {
      next.add(photoId);
      await supabase.from("favorites").insert({ album_id: album.id, photo_id: photoId, visitor_token: visitorToken });
    }
    setFavorites(next);
  }

  async function downloadPhoto(p: Photo) {
    const res = await fetch(photoUrl(p.storage_path));
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = p.file_name ?? "foto.jpg";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function downloadAll() {
    for (const p of photos) {
      await downloadPhoto(p);
      await new Promise((r) => setTimeout(r, 300));
    }
  }

  if (album === null) return <div className="min-h-screen flex items-center justify-center text-muted-foreground text-sm">Carregando…</div>;
  if (album === "notfound") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground px-6 text-center">
        <h1 className="font-display italic text-4xl mb-3">Álbum não encontrado</h1>
        <p className="text-sm text-muted-foreground mb-6">Verifique o link com sua fotógrafa.</p>
        <Link to="/" className="text-xs tracking-[0.2em] uppercase underline">Voltar</Link>
      </div>
    );
  }

  if (album.password_hash && !unlocked) {
    return (
      <div className="min-h-screen flex flex-col bg-background text-foreground">
        <header className="px-6 py-6 md:px-12">
          <Link to="/" className="text-sm tracking-[0.3em] uppercase">By Ana Esther</Link>
        </header>
        <main className="flex-1 flex items-center justify-center px-6">
          <div className="w-full max-w-sm text-center">
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-4">Álbum privado</p>
            <h1 className="font-display italic text-4xl mb-2">{album.event_name}</h1>
            <p className="text-sm text-muted-foreground mb-8">Digite a senha enviada pela fotógrafa.</p>
            <form onSubmit={submitPassword} className="space-y-3">
              <input
                type="password" required autoFocus value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-border bg-transparent px-4 py-3 text-sm text-center focus:outline-none focus:border-foreground"
              />
              {pwError && <p className="text-sm text-destructive">Senha incorreta</p>}
              <button disabled={pwLoading} className="w-full bg-foreground text-background px-6 py-3 text-xs tracking-[0.2em] uppercase disabled:opacity-50">
                {pwLoading ? "Aguarde…" : "Entrar"}
              </button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  const visible = showFavOnly ? photos.filter((p) => favorites.has(p.id)) : photos;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {album.cover_url && (
        <div className="relative h-[65vh] w-full overflow-hidden">
          <img src={album.cover_url} alt="" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6 text-white">
            <p className="text-xs tracking-[0.3em] uppercase mb-4 opacity-80">By Ana Esther</p>
            <h1 className="font-display italic text-5xl md:text-7xl drop-shadow-lg">{album.event_name}</h1>
            <p className="mt-4 text-sm tracking-[0.15em] uppercase opacity-90">
              {album.client_name}{album.event_date && ` · ${new Date(album.event_date).toLocaleDateString("pt-BR")}`}
            </p>
          </div>
        </div>
      )}

      {!album.cover_url && (
        <header className="text-center px-6 py-20 border-b border-border">
          <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-4">By Ana Esther</p>
          <h1 className="font-display italic text-5xl md:text-7xl">{album.event_name}</h1>
          <p className="mt-4 text-sm tracking-[0.15em] uppercase text-muted-foreground">
            {album.client_name}{album.event_date && ` · ${new Date(album.event_date).toLocaleDateString("pt-BR")}`}
          </p>
        </header>
      )}

      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="text-xs tracking-[0.2em] uppercase text-muted-foreground">
            {photos.length} fotos · {favorites.size} favoritas
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowFavOnly((s) => !s)}
              className={`text-xs tracking-[0.2em] uppercase px-4 py-2 border transition ${
                showFavOnly ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground"
              }`}
            >
              {showFavOnly ? "Ver todas" : "Favoritas"}
            </button>
            <button onClick={downloadAll} className="text-xs tracking-[0.2em] uppercase px-4 py-2 bg-foreground text-background hover:opacity-90">
              Baixar tudo
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-2 md:px-6 py-8">
        {visible.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground italic py-24">
            {photos.length === 0 ? "As fotos serão publicadas em breve." : "Nenhuma favorita ainda."}
          </p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-1 md:gap-2">
            {visible.map((p, i) => (
              <button key={p.id} onClick={() => setLightbox(photos.indexOf(p))}
                className="group relative aspect-[3/4] overflow-hidden bg-accent">
                <img src={photoUrl(p.storage_path)} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500" />
                {favorites.has(p.id) && (
                  <span className="absolute top-2 right-2 text-white drop-shadow">♥</span>
                )}
              </button>
            ))}
          </div>
        )}
      </main>

      {lightbox !== null && photos[lightbox] && (
        <Lightbox
          photos={photos} index={lightbox} onClose={() => setLightbox(null)}
          onIndexChange={setLightbox}
          isFav={favorites.has(photos[lightbox].id)}
          onToggleFav={() => toggleFavorite(photos[lightbox].id)}
          onDownload={() => downloadPhoto(photos[lightbox])}
        />
      )}

      <footer className="border-t border-border py-8 text-center text-xs tracking-[0.2em] uppercase text-muted-foreground mt-12">
        By Ana Esther · Fotografia
      </footer>
    </div>
  );
}

function Lightbox({ photos, index, onClose, onIndexChange, isFav, onToggleFav, onDownload }: {
  photos: Photo[]; index: number; onClose: () => void; onIndexChange: (i: number) => void;
  isFav: boolean; onToggleFav: () => void; onDownload: () => void;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft" && index > 0) onIndexChange(index - 1);
      if (e.key === "ArrowRight" && index < photos.length - 1) onIndexChange(index + 1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [index, photos.length, onClose, onIndexChange]);

  const p = photos[index];
  return (
    <div className="fixed inset-0 z-50 bg-foreground/95 flex flex-col">
      <div className="flex items-center justify-between px-6 py-4 text-background">
        <span className="text-xs tracking-[0.2em] uppercase opacity-70">{index + 1} / {photos.length}</span>
        <div className="flex gap-4">
          <button onClick={onToggleFav} className="text-xs tracking-[0.2em] uppercase hover:opacity-70">
            {isFav ? "♥ Favorita" : "♡ Favoritar"}
          </button>
          <button onClick={onDownload} className="text-xs tracking-[0.2em] uppercase hover:opacity-70">
            Baixar em alta
          </button>
          <button onClick={onClose} className="text-xs tracking-[0.2em] uppercase hover:opacity-70">Fechar</button>
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center px-4 pb-8 relative">
        {index > 0 && (
          <button onClick={() => onIndexChange(index - 1)} className="absolute left-4 text-background text-3xl opacity-60 hover:opacity-100">‹</button>
        )}
        <img src={photoUrl(p.storage_path)} alt="" className="max-h-full max-w-full object-contain" />
        {index < photos.length - 1 && (
          <button onClick={() => onIndexChange(index + 1)} className="absolute right-4 text-background text-3xl opacity-60 hover:opacity-100">›</button>
        )}
      </div>
    </div>
  );
}