import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/albums/$id")({
  head: () => ({ meta: [{ title: "Álbum — By Ana Esther" }, { name: "robots", content: "noindex" }] }),
  component: AlbumEditor,
});

type Album = { id: string; slug: string; client_name: string; event_name: string; event_date: string | null; cover_url: string | null };
type Photo = { id: string; storage_path: string; file_name: string | null; sort_order: number };

function AlbumEditor() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [album, setAlbum] = useState<Album | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [copied, setCopied] = useState(false);

  async function load() {
    const { data: a } = await supabase.from("albums").select("id, slug, client_name, event_name, event_date, cover_url").eq("id", id).single();
    setAlbum(a as Album);
    const { data: p } = await supabase.from("photos").select("id, storage_path, file_name, sort_order").eq("album_id", id).order("sort_order", { ascending: true });
    setPhotos((p as Photo[]) ?? []);
  }
  useEffect(() => { load(); }, [id]);

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length || !album) return;
    setUploading(true);
    setProgress({ done: 0, total: files.length });
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const path = `${user.user.id}/${album.id}/${crypto.randomUUID()}-${f.name}`;
        const { error: upErr } = await supabase.storage.from("photos").upload(path, f, {
          contentType: f.type, upsert: false,
        });
        if (upErr) throw upErr;
        const { error: insErr } = await supabase.from("photos").insert({
          album_id: album.id, storage_path: path, file_name: f.name, sort_order: photos.length + i,
        });
        if (insErr) throw insErr;
        setProgress({ done: i + 1, total: files.length });
      }
      await load();
      if (fileRef.current) fileRef.current.value = "";
    } catch (err: any) {
      alert(err.message ?? "Erro no upload");
    } finally {
      setUploading(false);
      setProgress(null);
    }
  }

  async function deletePhoto(p: Photo) {
    if (!confirm("Remover esta foto?")) return;
    await supabase.storage.from("photos").remove([p.storage_path]);
    await supabase.from("photos").delete().eq("id", p.id);
    load();
  }

  async function setCover(p: Photo) {
    const url = photoUrl(p.storage_path);
    await supabase.from("albums").update({ cover_url: url }).eq("id", id);
    load();
  }

  async function deleteAlbum() {
    if (!album) return;
    if (!confirm(`Apagar "${album.event_name}" e todas as fotos?`)) return;
    await supabase.storage.from("photos").remove(photos.map((p) => p.storage_path));
    await supabase.from("albums").delete().eq("id", album.id);
    navigate({ to: "/admin" });
  }

  function copyLink() {
    if (!album) return;
    const url = `${window.location.origin}/album/${album.slug}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (!album) return <div className="p-12 text-sm text-muted-foreground">Carregando…</div>;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between px-6 py-6 md:px-12 border-b border-border">
        <Link to="/admin" className="text-xs tracking-[0.2em] uppercase text-muted-foreground hover:text-foreground">
          ← Ateliê
        </Link>
        <div className="text-sm tracking-[0.3em] uppercase">By Ana Esther</div>
      </header>

      <main className="max-w-6xl mx-auto px-6 md:px-12 py-12">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-3">
              {album.client_name}{album.event_date && ` · ${new Date(album.event_date).toLocaleDateString("pt-BR")}`}
            </p>
            <h1 className="font-display italic text-5xl">{album.event_name}</h1>
          </div>
          <div className="flex gap-2">
            <button onClick={copyLink} className="border border-foreground px-5 py-3 text-xs tracking-[0.2em] uppercase hover:bg-foreground hover:text-background transition">
              {copied ? "Copiado ✓" : "Copiar link"}
            </button>
            <Link to="/album/$slug" params={{ slug: album.slug }} target="_blank"
              className="border border-border px-5 py-3 text-xs tracking-[0.2em] uppercase hover:border-foreground transition">
              Abrir álbum
            </Link>
            <button onClick={deleteAlbum} className="text-xs tracking-[0.2em] uppercase text-muted-foreground hover:text-destructive px-3">
              Apagar
            </button>
          </div>
        </div>

        <div className="border border-dashed border-border p-8 text-center mb-12">
          <input ref={fileRef} type="file" accept="image/*" multiple onChange={onUpload} disabled={uploading} className="hidden" id="fileup" />
          <label htmlFor="fileup" className="cursor-pointer inline-block">
            <p className="text-sm text-muted-foreground mb-2">
              {uploading && progress
                ? `Enviando ${progress.done} de ${progress.total}…`
                : "Arraste ou clique para enviar as fotos"}
            </p>
            <span className="inline-block bg-foreground text-background px-6 py-3 text-xs tracking-[0.2em] uppercase mt-2">
              {uploading ? "Aguarde…" : "Selecionar fotos"}
            </span>
          </label>
        </div>

        {photos.length === 0 ? (
          <p className="text-muted-foreground text-sm italic text-center py-16">Nenhuma foto ainda.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {photos.map((p) => (
              <div key={p.id} className="group relative aspect-square overflow-hidden bg-accent">
                <img src={photoUrl(p.storage_path)} alt={p.file_name ?? ""} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-foreground/60 opacity-0 group-hover:opacity-100 flex items-end justify-between p-3 transition-opacity">
                  <button onClick={() => setCover(p)} className="text-[10px] tracking-[0.2em] uppercase text-background hover:underline">
                    Capa
                  </button>
                  <button onClick={() => deletePhoto(p)} className="text-[10px] tracking-[0.2em] uppercase text-background hover:underline">
                    Apagar
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export function photoUrl(path: string) {
  const base = import.meta.env.VITE_SUPABASE_URL;
  return `${base}/storage/v1/object/public/photos/${path}`;
}