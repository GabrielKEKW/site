import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { generateSlug } from "@/lib/slug";
import { hashAlbumPassword } from "@/lib/album-password.functions";
import { useServerFn } from "@tanstack/react-start";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Ateliê — By Ana Esther" }, { name: "robots", content: "noindex" }] }),
  component: AdminHome,
});

type Album = {
  id: string; slug: string; client_name: string; event_name: string;
  event_date: string | null; created_at: string; password_hash: string | null;
};

function AdminHome() {
  const navigate = useNavigate();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const hashPw = useServerFn(hashAlbumPassword);

  const [form, setForm] = useState({
    client_name: "", client_email: "", client_phone: "",
    event_name: "", event_date: "", password: "",
  });

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("albums")
      .select("id, slug, client_name, event_name, event_date, created_at, password_hash")
      .order("created_at", { ascending: false });
    setAlbums((data as Album[]) ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function createAlbum(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;
      const slug = generateSlug(form.event_name || form.client_name);
      let password_hash: string | null = null;
      if (form.password.trim()) {
        const r = await hashPw({ data: { password: form.password.trim() } });
        password_hash = r.hash;
      }
      const { data, error } = await supabase.from("albums").insert({
        slug,
        client_name: form.client_name,
        client_email: form.client_email || null,
        client_phone: form.client_phone || null,
        event_name: form.event_name,
        event_date: form.event_date || null,
        password_hash,
        created_by: user.user.id,
      }).select("id").single();
      if (error) throw error;
      navigate({ to: "/admin/albums/$id", params: { id: data.id } });
    } catch (err: any) {
      alert(err.message ?? "Erro ao criar álbum");
    } finally {
      setCreating(false);
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between px-6 py-6 md:px-12 border-b border-border">
        <Link to="/" className="text-sm tracking-[0.3em] uppercase">By Ana Esther</Link>
        <button onClick={signOut} className="text-xs tracking-[0.2em] uppercase text-muted-foreground hover:text-foreground">
          Sair
        </button>
      </header>

      <main className="max-w-5xl mx-auto px-6 md:px-12 py-16">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-3">Ateliê</p>
            <h1 className="font-display italic text-5xl">Seus álbuns</h1>
          </div>
          <button
            onClick={() => setShowForm((s) => !s)}
            className="bg-foreground text-background px-6 py-3 text-xs tracking-[0.2em] uppercase hover:opacity-90"
          >
            {showForm ? "Cancelar" : "Novo álbum"}
          </button>
        </div>

        {showForm && (
          <form onSubmit={createAlbum} className="border border-border p-6 md:p-8 mb-12 space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Field label="Nome do cliente" value={form.client_name} onChange={(v) => setForm({ ...form, client_name: v })} required />
              <Field label="Nome do evento / ensaio" value={form.event_name} onChange={(v) => setForm({ ...form, event_name: v })} required />
              <Field label="E-mail do cliente" type="email" value={form.client_email} onChange={(v) => setForm({ ...form, client_email: v })} />
              <Field label="Telefone" value={form.client_phone} onChange={(v) => setForm({ ...form, client_phone: v })} />
              <Field label="Data do evento" type="date" value={form.event_date} onChange={(v) => setForm({ ...form, event_date: v })} />
              <Field label="Senha do álbum (opcional)" type="text" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
            </div>
            <button disabled={creating} className="bg-foreground text-background px-6 py-3 text-xs tracking-[0.2em] uppercase disabled:opacity-50">
              {creating ? "Criando…" : "Criar álbum"}
            </button>
          </form>
        )}

        {loading ? (
          <p className="text-muted-foreground text-sm">Carregando…</p>
        ) : albums.length === 0 ? (
          <p className="text-muted-foreground text-sm italic">Nenhum álbum ainda. Crie o primeiro.</p>
        ) : (
          <ul className="divide-y divide-border">
            {albums.map((a) => (
              <li key={a.id}>
                <Link
                  to="/admin/albums/$id" params={{ id: a.id }}
                  className="flex items-center justify-between py-6 hover:opacity-70 transition"
                >
                  <div>
                    <h3 className="font-display italic text-2xl">{a.event_name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {a.client_name}
                      {a.event_date && ` · ${new Date(a.event_date).toLocaleDateString("pt-BR")}`}
                      {a.password_hash && " · 🔒"}
                    </p>
                  </div>
                  <span className="text-xs tracking-[0.2em] uppercase text-muted-foreground">/{a.slug}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", required = false }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs tracking-[0.2em] uppercase text-muted-foreground mb-2">{label}</label>
      <input
        type={type} required={required} value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-border bg-transparent px-4 py-3 text-sm focus:outline-none focus:border-foreground"
      />
    </div>
  );
}