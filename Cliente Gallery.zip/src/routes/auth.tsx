import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — By Ana Esther" },
      { name: "description", content: "Área da fotógrafa." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin" });
    });
  }, [navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      navigate({ to: "/admin" });
    } catch (err: any) {
      setError(err.message ?? "Erro ao autenticar");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground overflow-hidden">
      {/* blobs decorativos da paleta */}
      <div aria-hidden className="pointer-events-none absolute -top-32 -left-32 h-96 w-96 rounded-full bg-brand-blush/60 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute top-1/3 -right-40 h-[28rem] w-[28rem] rounded-full bg-brand-peach/50 blur-3xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-40 left-1/4 h-96 w-96 rounded-full bg-[#FA5AD0]/30 blur-3xl" />

      <header className="relative px-6 py-6 md:px-12">
        <Link to="/" className="text-sm tracking-[0.3em] uppercase">By Ana Esther</Link>
      </header>
      <main className="relative flex-1 flex items-center justify-center px-6 pb-16">
        <div className="w-full max-w-sm">
          <h1 className="font-display italic font-black text-5xl leading-[1.05] mb-3">
            {mode === "signin" ? (
              <>Bem-<span className="relative inline-block">vinda
                <svg aria-hidden viewBox="0 0 120 10" className="absolute left-0 -bottom-2 w-full h-2 text-brand-peach" preserveAspectRatio="none">
                  <path d="M0 5 Q 15 0 30 5 T 60 5 T 90 5 T 120 5" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round"/>
                </svg>
              </span>.</>
            ) : (
              <>Criar <span className="text-brand-orange">conta</span>.</>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mb-8">
            {mode === "signin" ? "Acesse seu ateliê digital." : "Crie sua conta."}
          </p>

          <form onSubmit={onSubmit} className="space-y-4 bg-white/70 backdrop-blur-sm border-2 border-brand-blush rounded-3xl p-6 shadow-[0_20px_60px_-30px_rgba(237,32,72,0.35)]">
            <div>
              <label className="block text-[10px] tracking-[0.25em] uppercase text-brand-ink/70 mb-2">E-mail</label>
              <input
                type="email" required value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-brand-blush bg-white/80 px-4 py-3 text-sm rounded-full focus:outline-none focus:border-primary focus:bg-white transition"
              />
            </div>
            <div>
              <label className="block text-[10px] tracking-[0.25em] uppercase text-brand-ink/70 mb-2">Senha</label>
              <input
                type="password" required minLength={6} value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-brand-blush bg-white/80 px-4 py-3 text-sm rounded-full focus:outline-none focus:border-primary focus:bg-white transition"
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <button
              type="submit" disabled={loading}
              className="w-full bg-brand-ink text-white px-6 py-3 text-xs tracking-[0.3em] uppercase rounded-full hover:bg-[#FA5AD0] transition-colors disabled:opacity-50"
            >
              {loading ? "Aguarde…" : mode === "signin" ? "Entrar" : "Criar conta"}
            </button>
          </form>


          <button
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="mt-6 text-[10px] tracking-[0.3em] uppercase text-brand-ink/70 hover:text-primary w-full text-center transition-colors"
          >
            {mode === "signin" ? "Não tenho conta →" : "Já tenho conta →"}
          </button>
        </div>
      </main>
    </div>
  );
}