import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getArea, areas, type Area } from "@/lib/areas";

export const Route = createFileRoute("/servicos/$area")({
  loader: ({ params }) => {
    const area = getArea(params.area);
    if (!area) throw notFound();
    return { area };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Serviço não encontrado" }, { name: "robots", content: "noindex" }] };
    }
    const { area } = loaderData;
    const title = `${area.label} — By Ana Esther`;
    return {
      meta: [
        { title },
        { name: "description", content: area.desc },
        { property: "og:title", content: title },
        { property: "og:description", content: area.desc },
      ],
    };
  },
  component: ServicoPage,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center bg-background text-center p-8">
      <div>
        <p className="font-display italic font-black text-4xl mb-4">Serviço não encontrado</p>
        <Link to="/" className="text-primary underline text-sm">Voltar para a home</Link>
      </div>
    </div>
  ),
  errorComponent: ({ error, reset }) => (
    <div className="min-h-screen grid place-items-center bg-background text-center p-8">
      <div>
        <p className="font-display italic font-black text-3xl mb-4">Algo deu errado</p>
        <p className="text-sm text-muted-foreground mb-6">{error.message}</p>
        <button onClick={reset} className="text-primary underline text-sm">Tentar novamente</button>
      </div>
    </div>
  ),
});

function ServicoPage() {
  const { area } = Route.useLoaderData() as { area: Area };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* NAV */}
      <header className="flex items-center justify-between px-6 md:px-12 py-5 border-b border-border">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid place-items-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-display font-black italic text-lg leading-none pb-0.5">A</span>
          <div className="text-[10px] tracking-[0.3em] uppercase leading-tight">
            By Ana Esther<br />
            <span className="text-muted-foreground">Direção Criativa</span>
          </div>
        </Link>
        <nav className="flex items-center gap-6 text-[10px] tracking-[0.25em] uppercase">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
          <Link to="/orcamento" className="hover:text-primary transition-colors">Orçamento</Link>
        </nav>
      </header>

      {/* HERO */}
      <section className={`${area.bg} ${area.fg} py-24 md:py-36 px-6 md:px-12`}>
        <div className="mx-auto max-w-5xl">
          <p className="text-[10px] tracking-[0.4em] uppercase opacity-80 mb-6">Área · {area.label}</p>
          <h1 className="font-display font-black italic text-6xl md:text-8xl leading-[0.9]">{area.label}<span className="text-brand-peach">.</span></h1>
          <p className="mt-8 text-lg md:text-2xl max-w-2xl opacity-90 font-display italic">{area.tagline}</p>
        </div>
      </section>

      {/* INTRO */}
      <section className="mx-auto max-w-3xl px-6 md:px-12 py-20 md:py-28">
        <p className="text-[10px] tracking-[0.35em] uppercase text-primary mb-6">Sobre a área</p>
        <p className="text-lg md:text-xl leading-relaxed text-foreground/80">{area.intro}</p>
      </section>

      {/* INCLUI */}
      <section className="bg-brand-ink text-white py-20 md:py-28">
        <div className="mx-auto max-w-5xl px-6 md:px-12">
          <p className="text-[10px] tracking-[0.35em] uppercase text-brand-peach mb-6">O que está incluso</p>
          <h2 className="font-display italic font-black text-4xl md:text-5xl mb-12">Entregáveis</h2>
          <ul className="grid md:grid-cols-2 gap-4">
            {area.includes.map((item, i) => (
              <li key={i} className="flex gap-4 border border-white/10 rounded-2xl p-5">
                <span className="text-brand-peach font-display italic font-black text-2xl leading-none">→</span>
                <span className="text-sm md:text-base opacity-90">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* PROCESSO */}
      <section className="mx-auto max-w-5xl px-6 md:px-12 py-20 md:py-28">
        <p className="text-[10px] tracking-[0.35em] uppercase text-primary mb-6">Como funciona</p>
        <h2 className="font-display italic font-black text-4xl md:text-5xl mb-12">Processo</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {area.process.map((p) => (
            <div key={p.step} className="border border-border rounded-2xl p-6">
              <div className="font-display italic font-black text-4xl text-brand-orange">{p.step}</div>
              <p className="mt-3 text-sm md:text-base">{p.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-brand-peach text-brand-ink py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-6 md:px-12">
          <p className="text-[10px] tracking-[0.35em] uppercase mb-6">Dúvidas frequentes</p>
          <h2 className="font-display italic font-black text-4xl md:text-5xl mb-10">FAQ</h2>
          <div className="space-y-6">
            {area.faq.map((f, i) => (
              <div key={i} className="border-b border-brand-ink/20 pb-5">
                <p className="font-display italic font-black text-xl md:text-2xl">{f.q}</p>
                <p className="mt-2 text-sm md:text-base opacity-80">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA ORÇAMENTO */}
      <section className="bg-background py-20 md:py-28 text-center px-6">
        <p className="text-[10px] tracking-[0.35em] uppercase text-primary mb-6">Vamos conversar?</p>
        <h2 className="font-display italic font-black text-4xl md:text-6xl leading-none">Peça um orçamento<br />para {area.label.toLowerCase()}.</h2>
        <Link
          to="/orcamento"
          search={{ area: area.key }}
          className="inline-block mt-10 bg-brand-ink text-white px-10 py-4 text-xs tracking-[0.3em] uppercase rounded-full hover:bg-primary transition"
        >
          Solicitar orçamento
        </Link>
      </section>

      {/* OUTRAS ÁREAS */}
      <section className="bg-brand-ink text-white py-16 px-6 md:px-12">
        <div className="mx-auto max-w-5xl">
          <p className="text-[10px] tracking-[0.35em] uppercase text-brand-peach mb-6 text-center">Outras áreas</p>
          <div className="flex flex-wrap justify-center gap-3">
            {areas.filter((a) => a.key !== area.key).map((a) => (
              <Link
                key={a.key}
                to="/servicos/$area"
                params={{ area: a.key }}
                className="border border-white/30 rounded-full px-5 py-2 text-xs tracking-[0.25em] uppercase hover:bg-white hover:text-brand-ink transition"
              >
                {a.label}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-brand-ink text-white/70 py-8 text-center text-[10px] tracking-[0.3em] uppercase">
        © By Ana Esther · Direção Criativa
      </footer>
    </div>
  );
}