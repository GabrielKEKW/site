export type Area = {
  key: string;
  label: string;
  desc: string;
  bg: string;
  fg: string;
  tagline: string;
  intro: string;
  includes: string[];
  process: { step: string; text: string }[];
  faq: { q: string; a: string }[];
};

export const areas: Area[] = [
  {
    key: "design",
    label: "Design",
    desc: "Identidade visual, social kits e peças gráficas.",
    bg: "bg-brand-red",
    fg: "text-white",
    tagline: "Marca com alma, sistema com método.",
    intro:
      "Construção de identidade visual do zero ou refresh de marcas existentes — pensando no símbolo, na tipografia, nas cores e em como tudo respira nos diferentes pontos de contato.",
    includes: [
      "Logo principal, versão reduzida e monograma",
      "Paleta de cores e sistema tipográfico",
      "Manual de marca em PDF",
      "Kit de templates para redes sociais",
      "Peças pontuais: cartão, apresentação, e-book",
    ],
    process: [
      { step: "01", text: "Briefing e imersão na história da marca" },
      { step: "02", text: "Territórios visuais e direção de arte" },
      { step: "03", text: "Design do sistema e refinamento" },
      { step: "04", text: "Entrega de arquivos e manual" },
    ],
    faq: [
      { q: "Quanto tempo leva?", a: "Uma identidade completa leva em média de 3 a 5 semanas." },
      { q: "Preciso ter tudo pronto antes?", a: "Não. A gente constrói o briefing junto na primeira reunião." },
    ],
  },
  {
    key: "fotografia",
    label: "Fotografia",
    desc: "Ensaios autorais e álbuns privados em alta qualidade.",
    bg: "bg-brand-orange",
    fg: "text-white",
    tagline: "Imagem que carrega verdade.",
    intro:
      "Ensaios autorais, editoriais e cobertura fotográfica com direção de luz, styling e pós-produção editorial. Cada álbum é entregue em área privada online.",
    includes: [
      "Direção criativa e styling do ensaio",
      "Sessão fotográfica em locação ou estúdio",
      "Seleção e tratamento profissional",
      "Álbum online privado com download em alta",
      "Uso das imagens definido em contrato",
    ],
    process: [
      { step: "01", text: "Conversa inicial e referências" },
      { step: "02", text: "Planejamento de locação, styling e mood" },
      { step: "03", text: "Dia do ensaio" },
      { step: "04", text: "Edição e entrega do álbum privado" },
    ],
    faq: [
      { q: "Posso escolher as fotos?", a: "Sim. Você recebe uma pré-seleção para favoritar antes do tratamento final." },
      { q: "Onde acontece o ensaio?", a: "Definimos juntas — pode ser em locação externa, casa ou estúdio parceiro." },
    ],
  },
  {
    key: "video",
    label: "Vídeo",
    desc: "Direção, roteiro e edição para marcas e artistas.",
    bg: "bg-brand-ink",
    fg: "text-white",
    tagline: "Filme com direção, não só câmera.",
    intro:
      "Direção audiovisual completa para marcas, artistas e projetos culturais — do roteiro à entrega final, com equipe reduzida e foco em imagem autoral.",
    includes: [
      "Roteiro e direção criativa",
      "Captação de imagem e som",
      "Direção de arte da cena",
      "Edição, color e finalização",
      "Versões para redes e cinema/TV",
    ],
    process: [
      { step: "01", text: "Briefing e conceito" },
      { step: "02", text: "Pré-produção: roteiro, cast, locação" },
      { step: "03", text: "Diária(s) de gravação" },
      { step: "04", text: "Pós-produção e entrega" },
    ],
    faq: [
      { q: "Vocês têm equipe própria?", a: "Sim, com rede de colaboradores fixos por função (DP, som, arte, edição)." },
      { q: "Qual formato de entrega?", a: "Master em alta + cortes verticais e quadrados para redes." },
    ],
  },
  {
    key: "edicao",
    label: "Edição",
    desc: "Pós-produção de foto e vídeo com acabamento editorial.",
    bg: "bg-brand-peach",
    fg: "text-brand-ink",
    tagline: "O acabamento que muda o material.",
    intro:
      "Serviço de pós-produção avulsa para quem já tem material captado — tratamento de imagem, edição de vídeo, color grading e finalização com padrão editorial.",
    includes: [
      "Tratamento de fotografia (skin, luz, cor)",
      "Edição e montagem de vídeo",
      "Color grading",
      "Sound design e mixagem básica",
      "Motion e legendas quando necessário",
    ],
    process: [
      { step: "01", text: "Recebimento do material bruto" },
      { step: "02", text: "Definição de referência de acabamento" },
      { step: "03", text: "Edição com rodadas de revisão" },
      { step: "04", text: "Entrega dos arquivos finais" },
    ],
    faq: [
      { q: "Quantas revisões estão inclusas?", a: "Até 2 rodadas de revisão por projeto — extras são combinadas à parte." },
      { q: "Aceita material de outro fotógrafo/videomaker?", a: "Sim, desde que você tenha direito de uso do material." },
    ],
  },
  {
    key: "drone",
    label: "Drone",
    desc: "Captação aérea cinematográfica para eventos e brand films.",
    bg: "bg-brand-blush",
    fg: "text-brand-ink",
    tagline: "Outro ponto de vista, mesma direção.",
    intro:
      "Captação aérea com drone para brand films, eventos, arquitetura e paisagem — com operação certificada e planejamento de plano de voo.",
    includes: [
      "Operação de drone com piloto certificado",
      "Planejamento e autorização de voo",
      "Captação em 4K",
      "Seleção e edição das melhores tomadas",
      "Entrega dos brutos + cortes finalizados",
    ],
    process: [
      { step: "01", text: "Análise da locação e viabilidade de voo" },
      { step: "02", text: "Autorizações necessárias" },
      { step: "03", text: "Diária de captação" },
      { step: "04", text: "Edição e entrega" },
    ],
    faq: [
      { q: "Voa em qualquer lugar?", a: "Depende da região — algumas áreas exigem autorização prévia e outras não permitem voo." },
      { q: "Combina com o serviço de vídeo?", a: "Sim, é comum contratar em conjunto para brand films." },
    ],
  },
];

export function getArea(key: string) {
  return areas.find((a) => a.key === key);
}