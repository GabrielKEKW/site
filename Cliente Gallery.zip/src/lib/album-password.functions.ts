import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { createHash, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

function sha256(s: string) {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

export const verifyAlbumPassword = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ slug: z.string().min(1).max(100), password: z.string().min(1).max(200) }).parse(input),
  )
  .handler(async ({ data }) => {
    const supabase = createClient<Database>(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_PUBLISHABLE_KEY!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { data: album } = await supabase
      .from("albums")
      .select("password_hash")
      .eq("slug", data.slug)
      .maybeSingle();
    if (!album || !album.password_hash) return { ok: false as const };
    const a = Buffer.from(sha256(data.password), "hex");
    const b = Buffer.from(album.password_hash, "hex");
    if (a.length !== b.length) return { ok: false as const };
    return { ok: timingSafeEqual(a, b) };
  });

export const hashAlbumPassword = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ password: z.string().min(1).max(200) }).parse(input))
  .handler(async ({ data }) => ({ hash: sha256(data.password) }));