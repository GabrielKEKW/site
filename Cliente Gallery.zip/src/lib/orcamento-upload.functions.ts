import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const uploadInputSchema = z.object({
  files: z.array(
    z.object({
      name: z.string(),
      type: z.string(),
      data: z.string(), // base64 data URL
    })
  ),
});

export const uploadOrcamentoPhotos = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => uploadInputSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const folder = `orcamento-${crypto.randomUUID()}`;
    const results: { path: string; url: string }[] = [];

    for (const file of data.files) {
      const base64 = file.data.split(",")[1];
      if (!base64) continue;
      const bytes = Buffer.from(base64, "base64");
      const path = `${folder}/${file.name}`;

      const { error: uploadError } = await supabaseAdmin.storage
        .from("orcamentos")
        .upload(path, bytes, { contentType: file.type });

      if (uploadError) {
        throw new Error(`Upload failed: ${uploadError.message}`);
      }

      const { data: signedData, error: signError } = await supabaseAdmin.storage
        .from("orcamentos")
        .createSignedUrl(path, 60 * 60 * 24 * 7); // 7 dias

      if (signError) {
        throw new Error(`Signed URL failed: ${signError.message}`);
      }

      results.push({ path, url: signedData.signedUrl });
    }

    return results;
  });
